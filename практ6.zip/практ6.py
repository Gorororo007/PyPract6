import asyncio
import aiohttp
import requests
from typing import Dict, List, Optional

# API-эндпоинты
COINGECKO_API = "https://api.coingecko.com/api/v3"
USELESS_FACTS_API = "https://uselessfacts.jsph.pl/api/v2/facts/random"
OPEN_METEO_API = "https://api.open-meteo.com/v1/forecast"

async def fetch_async(session: aiohttp.ClientSession, url: str, params: Optional[Dict] = None) -> Dict:
    """Асинхронный GET-запрос."""
    async with session.get(url, params=params) as response:
        if response.status == 200:
            return await response.json()
        else:
            print(f"Ошибка {response.status}: {await response.text()}")
            return {}

def fetch_sync(url: str, params: Optional[Dict] = None) -> Dict:
    """Синхронный GET-запрос."""
    response = requests.get(url, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Ошибка {response.status_code}: {response.text}")
        return {}

async def main():
    print("🌐 Демонстрация работы с бесплатными API")
    print("1. Получить цену Bitcoin (синхронно)")
    print("2. Получить 3 случайных факта (асинхронно)")
    print("3. Получить погоду в Москве (асинхронно)")
    choice = input("Выберите действие: ")

    if choice == "1":
        # Синхронный запрос к CoinGecko
        data = fetch_sync(
            f"{COINGECKO_API}/simple/price",
            params={"ids": "bitcoin", "vs_currencies": "usd"}
        )
        print(f"💰 Цена Bitcoin: ${data.get('bitcoin', {}).get('usd', 'Нет данных')}")

    elif choice == "2":
        # Асинхронные запросы к USeless Facts
        async with aiohttp.ClientSession() as session:
            tasks = [fetch_async(session, USELESS_FACTS_API) for _ in range(3)]
            results = await asyncio.gather(*tasks)
            for i, fact in enumerate(results, 1):
                print(f"📌 Факт {i}: {fact.get('text', 'Нет данных')}")

    elif choice == "3":
        # Асинхронный запрос к Open-Meteo
        params = {
            "latitude": 55.7558,
            "longitude": 37.6176,
            "current_weather": "true"  # Исправлено: строка вместо bool
        }
        async with aiohttp.ClientSession() as session:
            data = await fetch_async(session, OPEN_METEO_API, params)
            temp = data.get("current_weather", {}).get("temperature", "Нет данных")
            print(f"☀ Погода в Москве: {temp}°C")

    else:
        print("❌ Неверный выбор.")

if __name__ == "__main__":
    asyncio.run(main())